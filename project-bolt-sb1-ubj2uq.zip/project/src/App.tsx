import React from 'react';
import ROICalculator from './components/ROICalculator';

function App() {
  return <ROICalculator />;
}

export default App;